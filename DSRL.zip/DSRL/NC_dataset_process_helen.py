import cv2
import numpy as np
import os
import shutil
import torch.nn as nn
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from load_utils import load_state_dict_from_url
import torchvision.datasets as datasets
from numpy import *
import math
from newPad2d import newPad2d
from tqdm import tqdm
import torch
from Similar_Mask_Generate import SMGBlock
from PIL import Image
from model import alexnet
background=[]
# [3,7,13,14,17,19,20,25,32,37,55,56,57,59,66,72,
#         83,89,93,95,104,105,106,118,119,123,124,125,
#             132,139,141,150,154,158,162,170,179,181,183,184,185,186,187,191,
#             199,210,216,224,225,234,236,240,242,252]
# img1 = cv2.imread(r'D:\dataset\helen\labels\232194_1\232194_1_lbl01.png')
# img2 = cv2.imread(r'D:\dataset\helen\labels\232194_1\232194_1_lbl02.png')
# img3 = cv2.imread(r'D:\dataset\helen\labels\232194_1\232194_1_lbl03.png')
#
# imgadd = cv2.add(img1, img2,img3)
# cv2.imshow('imgadd', imgadd)
# cv2.waitKey(0)
masklist=[{} for _ in range(3)]
file_dir = r"D:\dataset\helen\labels_val"
#all_files=[]
# test_files=[]
# fileHandler  = open (r"D:\dataset\helen\val.txt",  "r")
# while  True:
#     # Get next line from file
#     line  =  fileHandler.readline()
#     # If line is empty then end of file reached
#     if  not  line  :
#         break;
#     test_files.append(line.strip('\n').split(', ')[1])

    # Close Close
#fileHandler.close()
files = os.listdir(file_dir)
for file in files:
    file_path = os.path.join(file_dir, file)
    file_path1 = os.path.join(file_path, file + '_lbl01.png')
    img1 = cv2.imread(file_path1)
    for i in range(2,10):
        file_path2=os.path.join(file_path,file+'_lbl0'+str(i)+'.png')
        img2 = cv2.imread(file_path2)
        img1 = cv2.add(img1, img2)
        img_gray = cv2.cvtColor(img1, cv2.COLOR_RGB2GRAY)
        ret, img_face = cv2.threshold(img_gray, 127, 255, cv2.THRESH_BINARY)
        #a=f_map==img_gray
        file_hair=os.path.join(file_path,file+'_lbl10'+'.png')
        hair_img = cv2.imread(file_hair, cv2.IMREAD_GRAYSCALE)
        ret, hair_img = cv2.threshold(hair_img, 127, 255, cv2.THRESH_BINARY)
        file_background = os.path.join(file_path, file + '_lbl00' + '.png')
        background_img = cv2.imread(file_background, cv2.IMREAD_GRAYSCALE)
        ret, background_img = cv2.threshold(background_img, 127, 255, cv2.THRESH_BINARY)
        masklist[0][file]=img_face
        masklist[1][file]=hair_img
        masklist[2][file] = background_img
CHANNEL_NUM = 256
NUM_CLASSES = 2
def test(root,lines):
    net.eval()
    #filter_labels = [[] for _ in range(CHANNEL_NUM)]
    maxvalues=[[[] for _ in range(3)] for _ in range(CHANNEL_NUM)]
    fenzi=[[[] for _ in range(3)] for _ in range(CHANNEL_NUM)]
    fenmu = [[] for _ in range(CHANNEL_NUM)]
    for i in range(330):
        tpath = os.path.join(root + lines[i] + '.jpg')
        fopen = Image.open(tpath)
        img = cv2.imread(tpath)
        size = list(img.shape[0:2])
        size[0], size[1] = size[1], size[0]
        normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                         std=[0.229, 0.224, 0.225])
        transform=transforms.Compose([
            transforms.Resize(300),
            transforms.CenterCrop(300),
            transforms.ToTensor(),
            normalize
        ])
        inputs= transform(fopen).cuda()
        inputs=inputs.unsqueeze(0)
        outputs, f_maps, _ = net(inputs)
        #print(f_maps.size())
        f_maps = f_maps.squeeze().cpu().detach().numpy()
        for index, f_map in enumerate(f_maps):
            #print(f_map.shape())
            #f_map=f_map.data.cpu().numpy()
            #print(f_map.shape())
            if index not in background:
                f_map = np.expand_dims(f_map, 2) * 255# (11, 11, 1)
            #print(f_map)
                f_map = np.uint8(f_map)
            #print(f_map)

                f_map = cv2.resize(f_map,tuple(size))
                ret,f_map = cv2.threshold(f_map,127,255, cv2.THRESH_BINARY)
                ious={}
                ious_num=[]
                yu_2 = np.array(f_map)
                sum2 = np.sum(yu_2) / 255
                if sum2!=0:
                    fenmu[index].append(sum2)
                for j in range(3):
                    a = lines[i]
                    if np.sum(yu_2)!=0:
                        yu_1=np.array(masklist[j][a])
                    #yu_2=np.array(f_map)
                    #yu_2=map(int,yu_2)
                        sum1= np.sum(yu_1 & yu_2)/255
                    #sum2= np.sum(yu_1 | yu_2)
                        ious[j]=sum1/sum2
                        ious_num.append(sum1/sum2)
                        fenzi[index][j].append(sum1)

                    #entroy[index][a].append(sum1 / sum2)
                        if sum1 / sum2>0.04:
                            maxvalues[index][j].append(1)
                        else:
                            maxvalues[index][j].append(0)

            #filter_labels[index].append(filter_label)
    return maxvalues,fenzi,fenmu
root = 'D:/dataset/helen/val/face/'
#train_loader, test_loader = get_Data(root)
#print(type(train_loader))
device = torch.device("cuda")
net = alexnet.alex(num_class=NUM_CLASSES, pretrained=True, device=device)
#print(net)
net = net.to(device)
f=open('D:/dataset/helen/val.txt','r')
lines=f.read().splitlines()
maxvalues,fenzi,fenmu=test(root,lines)
filter_labels_final=[]
# for m in range(CHANNEL_NUM):
#     num=Counter(filter_labels[m])
#     filter_labels_final.append(Counter(filter_labels[m]).most_common(1)[0][0])
most_common = []
iou_values=[]
#print(type(maxvalues))
#print(len(maxvalues),len(maxvalues[0]),len(maxvalues[0][0]))
#print(maxvalues[0])
#maxvalues=np.array(maxvalues)
#print(type(maxvalues))
#print(maxvalues.shape,maxvalues[0])
maxvalues_mean=[[] for _ in range(CHANNEL_NUM)]
#entropy_mean=[[] for _ in range(CHANNEL_NUM)]
maxvalues_max=[]
H=[]
for i in range(CHANNEL_NUM):
    h = 0
    if i not in background:
        b = sum(fenmu[i])
        for j in range(3):
            if maxvalues[i][j]!=[]:
                maxvalues_mean[i].append(mean(maxvalues[i][j]))
        #a = sum(entroy[i][j])
        #entropy_mean[i].append(mean(entroy[i][j]))
            a=sum(fenzi[i][j])
            if a!=0:
                x=a/b
                h+=x*math.log(x)
    #print(i,j)
        if maxvalues_mean[i]!=[]:
            maxvalues_max.append(max(maxvalues_mean[i]))
        H.append(-h)
#maxvalues_mean=np.array(maxvalues_mean)
#maxvalues_mean=np.array(maxvalues_mean)

iou1=mean(maxvalues_max)
iou2=mean(H)
print(iou1,iou2)


