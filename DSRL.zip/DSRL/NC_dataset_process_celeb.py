import torch
from collections import Counter
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from load_utils import load_state_dict_from_url
from tqdm import tqdm
from Similar_Mask_Generate import SMGBlock
from newPad2d import newPad2d
import torchvision.datasets as datasets
from xml.etree import ElementTree as ET
import os
import cv2
import numpy as np
from numpy import *
import math
from PIL import Image
from model import alexnet
from model import vgg
img_path='D:/dataset/celeba/train.txt'
part_path='D:/dataset/celeba/part.txt'
imgroot='D:/dataset/celeba/image/train/'
imageindex={}
partaxis=[[] for _ in range(5)]
part=open(part_path,'r')
img=open(img_path,'r')
for line in part:
    line=line.strip()
    line=line.split(' ')
    partaxis[0].append((line[1],line[2]))
    partaxis[1].append((line[3], line[4]))
    partaxis[2].append((line[5], line[6]))
    partaxis[3].append((line[7], line[8]))
    partaxis[4].append((line[9], line[10]))
imagesize=(218,178)
background=[]
CHANNEL_NUM = 512
NUM_CLASSES = 2
maxvalues=[[[] for _ in range(5)]for _ in range(CHANNEL_NUM)]
maxindex=[[[] for _ in range(5)]for _ in range(CHANNEL_NUM)]
maxpart=[[[] for _ in range(5)]for _ in range(CHANNEL_NUM)]
formalsize=math.sqrt(imagesize[0]**2+imagesize[1]**2)
def test(root,lines):
    net.eval()
    for i in range(2004):
        tpath = os.path.join(root + lines[i])
        fopen = Image.open(tpath)
        normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                         std=[0.229, 0.224, 0.225])
        transform = transforms.Compose([
            transforms.Resize(300),
            transforms.CenterCrop(300),
            transforms.ToTensor(),
            normalize
        ])
        inputs = transform(fopen).cuda()
        inputs = inputs.unsqueeze(0)
        outputs, f_maps = net(inputs)
        f_maps = f_maps.squeeze().cpu().detach().numpy()
        for index, f_map in enumerate(f_maps):
            if index not in background:
                x = []
                y = []
                img = cv2.resize(np.uint8(np.expand_dims(f_map, 2) * 255), imagesize)
                ret, binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
                contours, hierarchy = cv2.findContours(binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                a = [0] * len(contours)
                if len(contours) > 0:
                    for k in range(0, len(contours)):
                        x.append(np.max(contours[k], axis=0))
                        y.append(np.min(contours[k], axis=0))
                        # print(k,x,y)
                        for m in range(y[k][0][0], x[k][0][0] + 1):
                            for n in range(y[k][0][1], x[k][0][1] + 1):
                                a[k] += img[n][m]
                        # print((x[k][0][0]-y[k][0][0])*(x[k][0][1]-y[k][0][1]))
                        # print()
                        p = x[k][0][0] - y[k][0][0] + 1
                        q = x[k][0][1] - y[k][0][1] + 1

                        a[k] = a[k] / (p + q)
                    for j in range(5):
                        maxvalues[index][j].append(max(a))
                        maxvolindex = a.index(max(a))
                        maxpart[index][j].append(((x[maxvolindex][0][0] + y[maxvolindex][0][0]) / 2,
                                                  x[maxvolindex][0][1] + y[maxvolindex][0][1] / 2))
                else:
                    for part in range(5):
                        maxvalues[index][part].append(0)
                        maxpart[index][part].append(None)
    for i in range(len(maxvalues)):
        for j in range(5):
            b = np.array(maxvalues[i][j]).argsort()[-100:][::-1]
            maxindex[i][j].append(b)
    return maxvalues, maxindex, maxpart
root = 'D:/dataset/celeba/image/train/face/'
device = torch.device("cuda")
net = vgg.vgg16(arch='vgg13_bn', cfg='B', num_class=NUM_CLASSES, device=device, pretrained=True, progress=True)
net = net.to(device)
f=open(r'D:\dataset\celeba\train.txt','r')
lines=f.read().splitlines()
maxvalues,maxindex,maxpart=test(root,lines)
result=[[] for _ in range(CHANNEL_NUM)]
mean1=[]
for i in range(CHANNEL_NUM):
    if i not in background:
        for j in range(5):
            d = []
            for k in range(2004):
                if (maxpart[i][j][k] != None) and (k in maxindex[i][j][0]):
                    # print(i,j,k,maxpart[i][j][k][0],partaxis[j][imageindex[lines[k]]][0],maxpart[i][j][k][1],partaxis[j][imageindex[lines[k]]][1])
                    d.append((math.sqrt(
                        (float(maxpart[i][j][k][0]) - float(partaxis[j][k][0])) ** 2 + (
                                    float(maxpart[i][j][k][1]) - float(partaxis[j][k][1])) ** 2)) /
                             formalsize)
            if d != []:
                D = np.std(d)
                # print(D)
                result[i].append(D)
            # print(result)
for i in range(len(result)):
    if result[i] != []:
        mean1.append(np.mean(result[i]))
mean = np.mean(mean1)
print(mean)