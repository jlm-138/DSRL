import xml.dom.minidom  as minidom
from collections import defaultdict
import torch
from collections import Counter
#import cv2
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
#import torchvision as tv
#import torchvision.models as models
from torch.utils.data import DataLoader
from load_utils import load_state_dict_from_url
#from SpectralClustering import spectral_clustering
from tqdm import tqdm
#import numpy as np
from Similar_Mask_Generate import SMGBlock
from newPad2d import newPad2d
#import os
import torchvision.datasets as datasets
from xml.etree import ElementTree as ET
import os
import cv2
import numpy as np
from numpy import *
import math
from PIL import Image
from model import vgg
from model import alexnet
ANNOT_FOLDER_NAME = "Annotations"
CAT_LIST = ['Dog']#,'Cat', 'Cow',  'Dog', 'Horse', 'Sheep']
num={'Cat':1000,'Sheep':279,'Cow':248,'Dog':1167,'Horse':418,'Bird':665}
classdict=[[] for _ in range(num[CAT_LIST[0]])]
ids=[]
partname=[]
#index=-1
length=[]
file_name=[]
wholelc=[{} for _ in range(num[CAT_LIST[0]])]
imagesize={}
partlist=['Head','Eye','Beak','Neck','Muzzle','Ear','Nose','Horn','Torso','Animal_Wing','Leg','Feet','Paw','Hoof','Tail']
#background=[20,33,52,71,103,156,166,187,194,232,240,241,247,253,291,336,337,363,391,419,429,439,465,468,479]
background=[95,201,244,274,384,484]
LAYERS='16'
def load_image_label_from_xml(img, voc12_root,index):
    #el_list = minidom.parse(os.path.join(voc12_root,ANNOT_FOLDER_NAME, img + '.xml')).getElementsByTagName('name')
    #print(os.path.join(voc12_root,ANNOT_FOLDER_NAME, img))
    Xtree = ET.parse(os.path.join(voc12_root,ANNOT_FOLDER_NAME, img + '.xml' ))
    #multi_cls_lab = np.zeros((20), np.float32)
    object = Xtree.findall("./object")
    for i in range(len(object)):
        name=object[i][0].text
        if name in CAT_LIST:

            a=classdict
            #part_list=minidom.parse(os.path.join(voc12_root,ANNOT_FOLDER_NAME, img + '.xml')).getElementsByTagName('hasparts')
            ids.append(object[i][1].text)
            #print(ids)
            if img not in file_name:
                index+=1
                file_name.append(img)
            classdict[index].append(img)
            classdict[index].append(name)
            for part in list(object[i]):
                for haspart in list(part):
                    if haspart.tag=="hasparts":
                        if (haspart.text)!=None:
                            lenth=len(haspart.text.split(","))
                        else:
                            lenth=0
                        length.append(lenth)
                        break
                    break


            for j in range(i+1,i+lenth+1):
                partname.append(object[j][0].text)
                x_axis = []
                y_axis = []
                for poly in list(object[j]):
                    a=object[j][0].text

                    partbianhao=[i for i, fruits in enumerate(partlist) if a == fruits][0]

                    for pt in list(poly):
                        b=wholelc[index]
                        if partbianhao not in wholelc[index]:
                            wholelc[index][partbianhao] = []
                        for axis in pt:
                            if (axis.tag)=='x':

                                x_axis.append(int(axis.text))

                            else:

                                y_axis.append(int(axis.text))
                wholelc[index][partbianhao].append(x_axis)
                wholelc[index][partbianhao].append(y_axis)

            #     for haparts in list(part):
            #


    # part= Xtree.findall("./object/parts/ispartof")
    # for onep in part:
    #     if (onep.text) in ids:
    #         classdict.append()
    #print(img)
    # print(len(ids))
    # print(len(partname))
    # print(len(x_axis))
    # print(len(y_axis))
    # print(length)
    #print(wholelc)
    return wholelc,index,classdict


            # cat_num = /

        #     CAT_NAME_TO_NUM[cat_name]
        #
        #     
        #
        # #multi_cls_lab[cat_num] = 1.0

    #return  multi_cls_lab
def load_image_label_list_from_xml(img_name_list, voc12_root):
    x=-1
    for img_name in img_name_list:
        wholelc,x,classdict=load_image_label_from_xml(img_name, voc12_root,x)
        
    return wholelc,classdict

def load_img_name_list(dataset_path):
            

    img_gt_name_list = open(dataset_path).read().splitlines()
    #print(img_gt_name_list)
            

    img_name_list = [img_gt_name.split(' ')[0]for img_gt_name in img_gt_name_list]



    return img_name_list
def getTwoDimensionListIndex(L,value):
    
    data = [data for data in L if data[0]==value] #data=[(53, 1016.1)]
    index = L.index(data[0])
    return index
root=r'D:\dataset\semanticPascalPart'

train_list=r'D:\dataset\semanticPascalPart\dog\trainval.txt'
img_name_list = load_img_name_list(train_list)
# #print(img_name_list)

#
label_list,classdict = load_image_label_list_from_xml(img_name_list,root)

masklist=[{} for _ in range(len(label_list))]
for i in range(len(label_list)):
    key=list(label_list[i].keys())
    val=list(label_list[i].values())

    file_path = 'D:/dataset/semanticPascalPart/dog/train' + '/' + classdict[i][1] + '/' + classdict[i][0] + '.jpg'
    #print(classdict[i][1],classdict[i][0])
    img = cv2.imread(file_path)
    #print(i)
    #print(classdict[i][1],classdict[i][0])
    for x in range(2,len(classdict[i])):
        if x%2==0 and str(type(img))=="<class 'NoneType'>":
            file_path = 'D:/dataset/semanticPascalPart/classification_single/train' + '/' + classdict[i][x+1] + '/' + classdict[i][
            x] + '.jpg'
            img = cv2.imread(file_path)

    #print(i)
    sp = img.shape[0:2]
    imagesize[classdict[i][0]]=sp
    #print(i)
    #if sp
    #for m in range(len(key)):
    for m in range(len(val)):
        mask = np.zeros(sp).astype(int)
        for j in range(len(val[m])):
            if j%2==0:
                #a=val[m][j][0]
                #print(m,j)
                mask[val[m][j+1][0]:val[m][j+1][2]+1,val[m][j][0]:val[m][j][1]+1]=1
        masklist[i][key[m]]=mask

CHANNEL_NUM = 512
NUM_CLASSES = 2
def test(lines,imagesize):
    net.eval()
    #filter_labels = [[] for _ in range(CHANNEL_NUM)]
    maxvalues=[[[] for _ in range(15)] for _ in range(CHANNEL_NUM)]
    fenzi=[[[] for _ in range(15)] for _ in range(CHANNEL_NUM)]
    fenmu = [[] for _ in range(CHANNEL_NUM)]
    for i in range(num[CAT_LIST[0]]):
        tpath = os.path.join(root + lines[i] + '.jpg')
        fopen = Image.open(tpath)
        img = cv2.imread(tpath)
        size = list(img.shape[0:2])
        size[0], size[1] = size[1], size[0]
        normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                         std=[0.229, 0.224, 0.225])
        transform = transforms.Compose([
            transforms.Resize(300),
            transforms.CenterCrop(300),
            transforms.ToTensor(),
            normalize
        ])
        inputs = transform(fopen).cuda()
        inputs = inputs.unsqueeze(0)
        outputs, f_maps= net(inputs)
        #print(f_maps.size())
        f_maps = f_maps.squeeze().cpu().detach().numpy()
        size = list(imagesize[lines[i]])
        size[0], size[1] = size[1], size[0]
        x = getTwoDimensionListIndex(classdict, lines[i])
        for index, f_map in enumerate(f_maps):
            #print(f_map.shape())
            #f_map=f_map.data.cpu().numpy()
            #print(f_map.shape())
            if index not in background:
                f_map = np.expand_dims(f_map, 2) * 255# (11, 11, 1)
            #print(f_map)
                f_map = np.uint8(f_map)
            #print(f_map)

                f_map = cv2.resize(f_map,tuple(size))
                ret,f_map = cv2.threshold(f_map,127,255, cv2.THRESH_BINARY)
                ious={}
                ious_num=[]
                yu_2 = np.array(f_map)
                sum2 = np.sum(yu_2) / 255
                if sum2!=0:
                    fenmu[index].append(sum2)
                for j in range(len(masklist[x])):
                    a = list(label_list[x].keys())[j]
                    if len(masklist[x])!=0 and (np.sum(yu_2))!=0:
                        yu_1=np.array(masklist[x][a])
                    #yu_2=np.array(f_map)
                    #yu_2=map(int,yu_2)
                        sum1= np.sum(yu_1 & yu_2)
                    #sum2= np.sum(yu_1 | yu_2)
                        ious[a]=sum1/sum2
                        ious_num.append(sum1/sum2)
                        fenzi[index][a].append(sum1)

                    #entroy[index][a].append(sum1 / sum2)
                        if sum1 / sum2>0.04:
                            maxvalues[index][a].append(1)
                        else:
                            maxvalues[index][a].append(0)

            #filter_labels[index].append(filter_label)
    return maxvalues,fenzi,fenmu
root = 'D:/dataset/semanticPascalPart/dog/val/Dog/'
#train_loader, test_loader = get_Data(root)
#print(type(train_loader))
device = torch.device("cuda")
net = vgg.vgg16(arch='vgg13', cfg='B', num_class=NUM_CLASSES, device=device, pretrained=True, progress=True)
#print(net)
net = net.to(device)
f=open('D:/dataset/semanticPascalPart/dog/trainval.txt','r')
lines=f.read().splitlines()
maxvalues,fenzi,fenmu=test(lines,imagesize)#filter_labels；maxvalues
filter_labels_final=[]
# for m in range(CHANNEL_NUM):
#     num=Counter(filter_labels[m])
#     filter_labels_final.append(Counter(filter_labels[m]).most_common(1)[0][0])
most_common = []
iou_values=[]
#print(type(maxvalues))
#print(len(maxvalues),len(maxvalues[0]),len(maxvalues[0][0]))
#print(maxvalues[0])
#maxvalues=np.array(maxvalues)
#print(type(maxvalues))
#print(maxvalues.shape,maxvalues[0])
maxvalues_mean=[[] for _ in range(CHANNEL_NUM)]
#entropy_mean=[[] for _ in range(CHANNEL_NUM)]
maxvalues_max=[]
H=[]
for i in range(CHANNEL_NUM):
    h = 0
    if i not in background:
        b = sum(fenmu[i])
        for j in range(15):
            if maxvalues[i][j]!=[]:
                maxvalues_mean[i].append(mean(maxvalues[i][j]))
        #a = sum(entroy[i][j])
        #entropy_mean[i].append(mean(entroy[i][j]))
            a=sum(fenzi[i][j])
            if a!=0:
                x=a/b
                h+=x*math.log(x)
    #print(i,j)
        if maxvalues_mean[i]!=[]:
            maxvalues_max.append(max(maxvalues_mean[i]))
        H.append(-h)
#maxvalues_mean=np.array(maxvalues_mean)
#maxvalues_mean=np.array(maxvalues_mean)

iou1=mean(maxvalues_max)
iou2=mean(H)
print(iou1,iou2)
