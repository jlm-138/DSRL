import xml.dom.minidom  as minidom
from collections import defaultdict
import torch
from collections import Counter
#import cv2
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
#import torchvision as tv
#import torchvision.models as models
from torch.utils.data import DataLoader
from load_utils import load_state_dict_from_url
#from SpectralClustering import spectral_clustering
from tqdm import tqdm
#import numpy as np
from Similar_Mask_Generate import SMGBlock
from newPad2d import newPad2d
#import os
import torchvision.datasets as datasets
from xml.etree import ElementTree as ET
import os
import cv2
import numpy as np
from numpy import *
import math
from PIL import Image
from model import alexnet
from model import vgg
ANNOT_FOLDER_NAME = "Annotations"
CAT_LIST = ['Bird','Cat', 'Cow', 'Dog', 'Horse', 'Sheep']
classdict=[[] for _ in range(806)]
ids=[]
partname=[]
#index=-1
length=[]
file_name=[]
wholelc=[{} for _ in range(806)]
imagesize={}
partlist=['Head','Eye','Beak','Neck','Muzzle','Ear','Nose','Horn','Torso','Animal_Wing','Leg','Feet','Paw','Hoof','Tail']
nums=[169,228,47,238,86,38]
background=[]
#background=[1,3,8,11,14,18,25,28,37,39,42,44,56,57,60,65,83,84,95,103,105,106,107,110,111,112,119,122,123,125,132,134,139,143,152,156,158,162,165,170,179,181,185,228]
def load_image_label_from_xml(img, voc12_root,index):
    
    #el_list = minidom.parse(os.path.join(voc12_root,ANNOT_FOLDER_NAME, img + '.xml')).getElementsByTagName('name')
   
    #print(os.path.join(voc12_root,ANNOT_FOLDER_NAME, img))
    Xtree = ET.parse(os.path.join(voc12_root,ANNOT_FOLDER_NAME, img + '.xml' ))
    #multi_cls_lab = np.zeros((20), np.float32)
    object = Xtree.findall("./object")
    
    for i in range(len(object)):
        name=object[i][0].text
        # 读取name
        if name in CAT_LIST:

            a=classdict
            #part_list=minidom.parse(os.path.join(voc12_root,ANNOT_FOLDER_NAME, img + '.xml')).getElementsByTagName('hasparts')
            ids.append(object[i][1].text)
            #print(ids)
            if img not in file_name:
                index+=1
                file_name.append(img)
            classdict[index].append(img)
            classdict[index].append(name)
            for part in list(object[i]):
                for haspart in list(part):
                    if haspart.tag=="hasparts":
                        if (haspart.text)!=None:
                            lenth=len(haspart.text.split(","))
                        else:
                            lenth=0
                        length.append(lenth)
                        break
                    break


            for j in range(i+1,i+lenth+1):
                partname.append(object[j][0].text)
                x_axis = []
                y_axis = []
                for poly in list(object[j]):
                    a=object[j][0].text

                    partbianhao=[i for i, fruits in enumerate(partlist) if a == fruits][0]

                    for pt in list(poly):
                        b=wholelc[index]
                        if partbianhao not in wholelc[index]:
                            wholelc[index][partbianhao] = []
                        for axis in pt:
                            if (axis.tag)=='x':

                                x_axis.append(int(axis.text))

                            else:

                                y_axis.append(int(axis.text))
                wholelc[index][partbianhao].append(x_axis)
                wholelc[index][partbianhao].append(y_axis)

            #     for haparts in list(part):
            #



    return wholelc,index,classdict
            

            # cat_num = /

        #     CAT_NAME_TO_NUM[cat_name]
        #
        #     
        #
        # #multi_cls_lab[cat_num] = 1.0

        
    #return  multi_cls_lab
def load_image_label_list_from_xml(img_name_list, voc12_root):
    x=-1
    for img_name in img_name_list:
        wholelc,x,classdict=load_image_label_from_xml(img_name, voc12_root,x)
        
    return wholelc,classdict

def load_img_name_list(dataset_path):
            

    img_gt_name_list = open(dataset_path).read().splitlines()
    #print(img_gt_name_list)
            

    img_name_list = [img_gt_name.split(' ')[0]for img_gt_name in img_gt_name_list]

  

    return img_name_list
def getTwoDimensionListIndex(L,value):

    data = [data for data in L if data[0]==value] #data=[(53, 1016.1)]
    index = L.index(data[0])
    return index
root=r'D:\dataset\semanticPascalPart'

train_list=r'D:\dataset\semanticPascalPart\classification\val\dataset.txt'
img_name_list = load_img_name_list(train_list)
# #print(img_name_list)

#
label_list,classdict = load_image_label_list_from_xml(img_name_list,root)

masklist=[{} for _ in range(len(label_list))]
for i in range(len(label_list)):
    key=list(label_list[i].keys())
    val=list(label_list[i].values())

    file_path = 'D:/dataset/semanticPascalPart/classification/val' + '/' + classdict[i][1] + '/' + classdict[i][0] + '.jpg'
    #print(classdict[i][1],classdict[i][0])
    img = cv2.imread(file_path)
    #print(i)
    #print(classdict[i][1],classdict[i][0])
    for x in range(2,len(classdict[i])):
        if x%2==0 and str(type(img))=="<class 'NoneType'>":
            file_path = 'D:/dataset/semanticPascalPart/classification_single/train' + '/' + classdict[i][x+1] + '/' + classdict[i][
            x] + '.jpg'
            img = cv2.imread(file_path)

    #print(i)
    sp = img.shape[0:2]
    imagesize[classdict[i][0]]=sp
    #print(i)
    #if sp
    #for m in range(len(key)):
    for m in range(len(val)):
        mask = np.zeros(sp).astype(int)
        for j in range(len(val[m])):
            if j%2==0:
                #a=val[m][j][0]
                #print(m,j)
                mask[val[m][j+1][0]:val[m][j+1][2]+1,val[m][j][0]:val[m][j][1]+1]=1
        masklist[i][key[m]]=mask

CHANNEL_NUM = 512
NUM_CLASSES = 6
#pretrain_model = r'C:\Users\Dell\PycharmProjects\iccnn\icCNN\result\voc\multi\vgg16\log\model_11_0.8271421495789995.pth'
def test(lines,imagesize):
    net.eval()
    #filter_labels = [[] for _ in range(CHANNEL_NUM)]
    maxvalues=[[[[] for _ in range(6)] for _ in range(15)] for _ in range(CHANNEL_NUM)]
    fenzi=[[[] for _ in range(15)] for _ in range(CHANNEL_NUM)]
    fenmu = [[] for _ in range(CHANNEL_NUM)]
    for i in range(806):
        tpath = os.path.join(root + classdict[i][1]+'/'+lines[i] + '.jpg')
        fopen = Image.open(tpath)
        img = cv2.imread(tpath)
        size = list(img.shape[0:2])
        size[0], size[1] = size[1], size[0]
        normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                         std=[0.229, 0.224, 0.225])
        transform = transforms.Compose([
            transforms.Resize(300),
            transforms.CenterCrop(300),
            transforms.ToTensor(),
            normalize
        ])
        inputs = transform(fopen).cuda()
        inputs = inputs.unsqueeze(0)
        outputs, f_maps= net(inputs)
        #print(f_maps.size())
        f_maps = f_maps.squeeze().cpu().detach().numpy()
        size = list(imagesize[lines[i]])#lines[idx]=lines[i]
        size[0], size[1] = size[1], size[0]
        x = getTwoDimensionListIndex(classdict, lines[i])
        for index, f_map in enumerate(f_maps):
            #print(f_map.shape())
            #f_map=f_map.data.cpu().numpy()
            #print(f_map.shape())

            f_map = np.expand_dims(f_map, 2) * 255# (11, 11, 1)
            #print(f_map)
            f_map = np.uint8(f_map)
            #print(f_map)

            f_map = cv2.resize(f_map,tuple(size))
            ret,f_map = cv2.threshold(f_map,127,255, cv2.THRESH_BINARY)
            ious={}
            ious_num=[]
            yu_2 = np.array(f_map)
            sum2 = np.sum(yu_2) / 255
            if sum2!=0:
                fenmu[index].append(sum2)
            for j in range(len(masklist[x])):
                a = list(label_list[x].keys())[j]
                if len(masklist[x])!=0 and (np.sum(yu_2))!=0:
                    yu_1=np.array(masklist[x][a])
                    #yu_2=np.array(f_map)
                    #yu_2=map(int,yu_2)
                    sum1= np.sum(yu_1 & yu_2)
                    #sum2= np.sum(yu_1 | yu_2)
                    ious[a]=sum1/sum2
                    ious_num.append(sum1/sum2)
                    fenzi[index][a].append(sum1)

                    #entroy[index][a].append(sum1 / sum2)
                    if sum1 / sum2>0.04:
                        maxvalues[index][a][CAT_LIST.index(classdict[i][1])].append(1)
                    else:
                        maxvalues[index][a][CAT_LIST.index(classdict[i][1])].append(0)

            #filter_labels[index].append(filter_label)
    return maxvalues,fenzi,fenmu
root = 'D:/dataset/semanticPascalPart/classification/val/'
#train_loader, test_loader = get_Data(root)
#print(type(train_loader))
device = torch.device("cuda")
net = vgg.vgg16(arch='vgg13', cfg='B', num_class=NUM_CLASSES, device=device, pretrained=True, progress=True)
#print(net)
net = net.to(device)
f=open('D:/dataset/semanticPascalPart/classification/val/dataset.txt','r')
lines=f.read().splitlines()
maxvalues,fenzi,fenmu=test(lines,imagesize)
filter_labels_final=[]
# for m in range(CHANNEL_NUM):
#     num=Counter(filter_labels[m])
#     filter_labels_final.append(Counter(filter_labels[m]).most_common(1)[0][0])
most_common = []
iou_values=[]
#print(type(maxvalues))
#print(len(maxvalues),len(maxvalues[0]),len(maxvalues[0][0]))
#print(maxvalues[0])
#maxvalues=np.array(maxvalues)
#print(type(maxvalues))
#print(maxvalues.shape,maxvalues[0])
maxvalues_mean=[[] for _ in range(CHANNEL_NUM)]
#entropy_mean=[[] for _ in range(CHANNEL_NUM)]
maxvalues_max=[]
H=[]
for i in range(CHANNEL_NUM):
    h = 0
    b = sum(fenmu[i])
    for j in range(15):
        sum1=[]
        for k in range(6):
            if maxvalues[i][j][k]!=[]:
                sum1.append(sum(maxvalues[i][j][k])/nums[k])
        if sum1!=[]:
            maxanimal=sum1.index(max(sum1))
        if maxvalues[i][j][maxanimal]!=[]:
            maxvalues_mean[i].append(mean(maxvalues[i][j][maxanimal]))
        else:
            maxvalues_mean[i].append(0)
        #a = sum(entroy[i][j])
        #entropy_mean[i].append(mean(entroy[i][j]))
        a=sum(fenzi[i][j])
        if a!=0:
            x=a/b
            h+=x*math.log(x)
    #print(i,j)
    if maxvalues_mean[i]!=[]:
        maxvalues_max.append(max(maxvalues_mean[i]))
    H.append(-h)
#maxvalues_mean=np.array(maxvalues_mean)
#maxvalues_mean=np.array(maxvalues_mean)

iou1=mean(maxvalues_max)
iou2=mean(H)
print(iou1,iou2)
