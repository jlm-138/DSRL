import matplotlib.pyplot as plt
import numpy as np
import torch
import math



def initialize_U(samples, classes):
    U = np.random.rand(samples, classes)  
    sumU = 1 / np.sum(U, axis=1)  
    U = np.multiply(U.T, sumU)  

    return U.T



def distance(X, centroid):
    # print(type(X))
    # a=X-centroid.numpy()
    # print(type(a))
    # b=np.sum(a**2,axis=1)
    # c=np.sum(b,axis=1)
    return np.sqrt(np.sum(np.sum((X - centroid.numpy()) ** 2, axis=1), axis=1))


def computeU(det, X, centroids, m=2):
    sampleNumber = X.shape[0]  
    classes = len(centroids)
    U = np.zeros((sampleNumber, classes))
  
    for i in range(classes):
        for k in range(classes):
            # print(distance(X, centroids[i]))
            # a=distance(X, centroids[i])
            # b=distance(X, centroids[k])
            U[:, i] += distance(X, centroids[k]) ** (-2 / (m - 1))
        # print(U[:,i])
        U[:, i] += (np.array(det ** (-2 / (m - 1)))).repeat(sampleNumber)
        # b=U[:, i]
        # a=distance(X, centroids[i])
        b = (distance(X, centroids[i])) ** (-2 / (m - 1))
        # print(b)
        U[:, i] = ((distance(X, centroids[i])) ** (-2 / (m - 1))) / U[:, i]
        # print(U[:,i])

    return U


def cluster(data, m, feature_size, classes, EPS):
    
    lanmda = 1.1
    sampleNumber = data.shape[0]  
    cNumber = data.shape[1]  
    U = initialize_U(sampleNumber, classes) 
    U_old = np.zeros((sampleNumber, classes))
    # print(classes)

    while True:
        centroids = [[[] for _ in range(cNumber)] for _ in range(classes)]
  
        det_num = 0
        for j in range(classes):
            dem = np.zeros((cNumber, feature_size))
            for i in range(sampleNumber):
                dem0 = torch.from_numpy(data[i]) * (
                    torch.from_numpy(np.array(U[i][j] ** m)).repeat(cNumber, feature_size))
                dem = dem + np.array(dem0)
            centroids[j] = dem / (torch.from_numpy(np.array(np.sum(U[:, j] ** m))).repeat(cNumber, feature_size))
            det_num += distance(data, centroids[j]) ** 2
        det = (lanmda / (classes * sampleNumber)) * det_num
        det = np.sum(det)
        det = np.sqrt(det)
        U_old = U.copy()
        U = computeU(det, data, centroids, m)  
        if np.max(np.abs(U - U_old)) < EPS:
            return centroids, U, det


def fs(x, u, v, m):
    feature_size = 324
    n = x.shape[1]
    c = len(v)
    a = 0
    b = 0
    y = torch.zeros(n, feature_size)
    # um = u**m
    # print(len(v),v[0].shape)
    for j in range(c):
        y += v[j]

    v_mean = y / c
    # print(v_mean.numpy().shape)
    for j in range(c):
        # print(type(trainX),trainX,type(centroids[j]),centroids[j])
        a += (u[:, j] ** m) * (distance(x, v[j]) ** 2)
        # d2 = pairwise_squared_distances(x, v)
        # print(type(trainX),trainX,type(centroids[j]),centroids[j])
        # np.sum((v_mean.numpy()- v[j].numpy()) ** 2,axis=1)
        z = np.sum(np.sum((v_mean.numpy() - v[j].numpy()) ** 2, axis=1), axis=0)
        b += (u[:, j] ** m) * z
    # distance_v_mean_squared = np.linalg.norm(v - v_mean, axis=1, keepdims=True)**2

    return np.sum(a - b)


def pcaes(x, u, v, m):
    feature_size = 121
    n = x.shape[1]
    c = len(v)
    a = np.square(u).sum()
    b = np.min(np.square(u).sum(axis=0))
    v_new = []
    d = 0
    y = torch.zeros(n, feature_size)
    for j in range(c):
        v_new.append(v[j].numpy())

        # um = u**m
        # print(len(v),v[0].shape)

        y += v[j]

    v_mean = y / c
    for j in range(c):
        # print(type(trainX),trainX,type(centroids[j]),centroids[j])
        x = distance(v_new, v[j]) ** 2
        x[x == 0.0] = np.inf
        z = np.sum(np.sum((v_mean.numpy() - v[j].numpy()) ** 2, axis=1), axis=0) / c
        d += math.exp(-np.min(b) / z)
    return a / b - d


def pc(x, u, v, m):
    n = x.shape[0]
    return np.square(u).sum() / n


def xb(x, u, v, m):
    n = x.shape[0]
    c = len(v)
    a = 0
    d = []
    v_new = []
    for j in range(c):
        v_new.append(v[j].numpy())
    for j in range(c):
        # print(type(trainX),trainX,type(centroids[j]),centroids[j])
        a += (u[:, j] ** m) * (distance(x, v[j]) ** 2)
        b = distance(v_new, v[j]) ** 2
        b[b == 0.0] = np.inf
        d.append(np.min(b))
    # um = u ** m

    # d2 = pairwise_squared_distances(x, v)
    # v2 = pairwise_squared_distances(v, v)

    # b[b == 0.0] = np.inf

    return np.sum(a / (n * min(d)))


methods = [xb]


def spectral_clustering(epoch, trainX, n_cluster=11):
    EPS = 1e-5  
    m = 2  
    # classes = n_cluster  
   
    feature_size = 324
    results = []

    # cluster data for different number of clusters
    #cs = np.arange(10,11 )
    #for c in cs:
    #v, U, det = cluster(trainX, m, feature_size, c, EPS)
        ## print(v[0],v[0][0],v[0][0][0])
        ## calculate cluster validity indices
        #results.append([])
        #for method in methods:
            #u = U
            #print('classesnum', c, 'methon:', method)
            #result = method(trainX, u, v, m)
            ## print(result,type(result))
            #results[-1].append(result)
    ## print(results,type(results))
    #results = np.array(results)

    #def normalization(data):
        #_range = np.max(data) - np.min(data)
        #return (data - np.min(data)) / _range

    #ny = 2
    #nx = 2
    #targets = "min max".split()
    ## plot cluster validity indices
    #for i, method in enumerate(methods):
        #plt.subplot(ny, nx, 1 + i)
        #column = normalization(results[:, i])
        #plt.plot(cs, column)

        ## find best cluster size for cluster validity index
        #if targets[i] == "min":
            #c = cs[np.argmin(column)]
        #else:
            #c = cs[np.argmax(column)]

        #plt.title("%s, %s is at %d" % (method.__name__, targets[i], c))

        #plt.plot([c, c], [np.min(column), np.max(column)])

    #plt.tight_layout()
    #plt.savefig("cvi %d.png" % (epoch), dpi=300)
    #plt.close()
    # plot data
    # plt.clf()
    ## v = fcm(x, c_true)
    ## v, U, det = cluster(trainX, m, feature_size, classes, EPS)
    ## plt.plot(x[:, 0], x[:, 1], 'bo', markersize=3, markeredgewidth=0.5, markeredgecolor='black')
    ## plt.plot(v[:, 0], v[:, 1], 'ro', markersize=3, markeredgewidth=0.5, markeredgecolor='black')

    ## plt.tight_layout()
    ## plt.savefig("plot.png", dpi=300)
    ## print(U)
    centroids, U, det = cluster(trainX, m, feature_size, n_cluster, EPS)
    v=centroids
    result = xb(trainX, U, v, m)
    loss = 0
    # print(centroids)
    sampleNumber = trainX.shape[0]
    for j in range(n_cluster):
        # print(type(trainX),trainX,type(centroids[j]),centroids[j])
        loss += (U[:, j] ** m) * (distance(trainX, centroids[j]) ** 2)

    noise = [1] * sampleNumber - np.sum(U, axis=1)
    loss += (noise ** 2) * (det ** 2)
    # print(noise)
    # loss+=(noise**2)*(det**2)
    noise = noise.reshape(-1, 1)
    U = np.append(U, noise, axis=1)
    cluster_result = []
    loss = loss / np.linalg.norm(loss)
    loss = (np.sum(loss)) / 10
    #loss2 = []
    for i in range(n_cluster + 1):
        ## labels = np.zeros(trainX.shape[0])
        labels = np.argmax(U, axis=1)
        idx = np.where(labels == i)[0]
        ## print('loss')
        ## cluster_result.append(idx.tolist())
        #X = np.zeros((trainX.shape[1], feature_size))
        #trainsc = []
        ## x=0
        #loss2 = np.array([])
        #if (idx.shape[0]) != 0:
            #for j in idx:
                ## print(i,j)
                ## print((trainX[j]).shape,trainX[j][0][0])
                #X += trainX[j]
                ## print(X[0][0])
                #trainsc.append(trainX[j].tolist())

                ## x+=1
            #sc = X / (idx.shape[0])
            ## print(sc[0][0])
            #loss2 = np.concatenate(((distance(np.array(trainsc), torch.from_numpy(sc)) ** 2), loss2))
        # print(loss2)
        print(f'cluster: {i}, idx: {idx}')
    #loss2 = loss2 / np.linalg.norm(loss2)
    #loss2 = (np.sum(loss2)) / 10

    # print(cluster_result)
    return loss,result#, loss2