#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import defaultdict
import torch
import cv2
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import torchvision as tv
import torchvision.models as models
from torch.utils.data import DataLoader
from load_utils import load_state_dict_from_url
from SpectralClustering import spectral_clustering
from tqdm import tqdm
import numpy as np
from Similar_Mask_Generate import SMGBlock
from newPad2d import newPad2d
import os
import torchvision.datasets as datasets
from PIL import Image, ImageFilter
IS_TRAIN = 0  # 0/1
LAYERS = '16'
NUM_CLASSES = 6
save_path = '/home/jzj/icCNN/log/'  # for get_feature
pretrain_model = r'C:\Users\Dell\PycharmProjects\iccnn\icCNN\result\voc\multi\alex\log\model_17_0.7414561664190193iccnn.pth'  
BATCHSIZE = 256  # bs
LR = 0.0001  
EPOCH = 25  
center_num = 10 
F_MAP_SIZE = 361
CHANNEL_NUM = 256
#if LAYERS == '18':
    #CHANNEL_NUM = 256
#elif LAYERS == '50':
    #CHANNEL_NUM = 1024

_all__ = ['alexnet']
model_urls = {
    'alexnet': 'https://download.pytorch.org/models/alexnet-owt-4df8aa71.pth',
}

class AlexNet(nn.Module):
    def __init__(self, num_classes=NUM_CLASSES, init_weights=True):
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(  
            nn.Conv2d(3, 64, 11, stride=4, padding=2),  
            nn.ReLU(inplace=True),  
            nn.MaxPool2d(kernel_size=3, stride=2),  
            nn.Conv2d(64, 192, kernel_size=5, padding=2),  # output[128, 27, 27]
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),  # output[128, 13, 13]
            nn.Conv2d(192, 384, kernel_size=3, padding=1),  # output[192, 13, 13]
            nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1),  # output[192, 13, 13]
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),  # output[128, 13, 13]
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),  # output[128, 6, 6]
        )
        self.target_layer = 15
        self.pad2d = newPad2d(1)
        self.smg = SMGBlock(channel_size=CHANNEL_NUM)
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))
        self.classifier = nn.Sequential(
            nn.Dropout(p=0.5),
  
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096, num_classes),
        )
        if init_weights:
            self._initialize_weights()

    def forward(self, x, eval=False):
        for layer in self.features[:self.target_layer + 1]:
            if isinstance(layer, nn.Conv2d):
                x = self.pad2d(x)
            x = layer(x)
            #print(x.shape,layer)
        if eval:
            return x
        corre_matrix = self.smg(x)
        f_map = x.detach()
        for layer in self.features[self.target_layer + 1:]:
            if isinstance(layer, nn.Conv2d):
                # print(x.shape)
                x = self.pad2d(x)
                # print(x.shape)
            x = layer(x)
            # print(x.shape)
        x = self.avgpool(x)

        x = torch.flatten(x, 1)
        # print(x.shape)
        x = self.classifier(x)
        return x, f_map, corre_matrix

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')  
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01) 
                nn.init.constant_(m.bias, 0)


def alex(num_class, device=None, pretrained=False, progress=True, **kwargs):
    if pretrained:
        kwargs['init_weights'] = False
    model = AlexNet(num_class, **kwargs)
    # print(model_urls['alexnet'])
    if pretrained:
        if pretrain_model is None:
            state_dict = load_state_dict_from_url(model_urls['alexnet'], progress=progress)
            pretrained_dict = {k: v for k, v in state_dict.items() if 'classifier' not in k}
            model_dict = model.state_dict()
            model_dict.update(pretrained_dict)
            model.load_state_dict(model_dict)
        else:
            device = torch.device("cuda")
            model = model.to(device)
            print(f'Load Pth: {pretrain_model}')
            pretrained_dict = torch.load(pretrain_model)
            # if IS_TRAIN == 0:
            #     pretrained_dict = {k[k.find('.') + 1:]: v for k, v in pretrained_dict.items()}
            model.load_state_dict(pretrained_dict)
    if device is not None:
        model = model.to(device)
    return model

def get_Data(root, batch_size=1, workers=0, pin_memory=True):
    traindir = os.path.join(root, 'train')
    valdir = os.path.join(root, 'val')
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])

    train_dataset = datasets.ImageFolder(
        traindir,
        transforms.Compose([
            transforms.RandomResizedCrop(300),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            normalize
        ])
    )
    val_dataset = datasets.ImageFolder(
        valdir,
        transforms.Compose([
            transforms.Resize(300),
            transforms.CenterCrop(300),
            transforms.ToTensor(),
            normalize
        ])
    )

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=workers,
        pin_memory=pin_memory,
        sampler=None
    )
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=workers,
        pin_memory=pin_memory
    )
    return train_loader, val_loader


def test(test_loader):
    num = 0
    record = defaultdict(int)

    net.eval()
    for idx, (inputs, labels) in enumerate(tqdm(test_loader, desc='[Test]', dynamic_ncols=True)):
        inputs, labels = inputs.cuda(), labels.cuda().long()
        outputs, f_maps, _ = net(inputs)
        #print(f_maps.shape)
        outputs = torch.argmax(outputs, dim=1)

        # if outputs[0] != labels[0]:
        #     continue
        #
        # if num >= 100:
        #     break
        #
        # if record[labels[0].item()] >= 10:
        #     continue

        num += 1
        record[labels[0].item()] += 1

        inputs = inputs.squeeze()
        inputs = inputs.cpu().numpy()
        inputs[0, ::] = inputs[0, ::] * 0.229 + 0.485
        inputs[1, ::] = inputs[1, ::] * 0.224 + 0.456
        inputs[2, ::] = inputs[2, ::] * 0.225 + 0.406
        inputs = np.transpose(inputs, (1, 2, 0))
        inputs = inputs * 255

        f_maps = f_maps.squeeze().cpu().detach().numpy()  # (256, 11, 11)
        # f_map = torch.max(f_maps, dim=0)[0].cpu().numpy()
        # f_map = np.uint8(np.expand_dims(f_map, 2) * 255)
        #isexist = 1
        for index, f_map in enumerate(f_maps):
            #print(f_map)
            f_map = np.expand_dims(f_map, 2) * 255# (11, 11, 1)
            #print(f_map)
            f_map = np.uint8(f_map)
            #print(f_map)
            f_map = cv2.resize(f_map, (300, 300))
            ret, binary= cv2.threshold(f_map,60, 255, cv2.THRESH_BINARY)
            #print(f_map.shape)
            #inputs=cv2.UMat(inputs).get()
            contours, hierarchy = cv2.findContours(binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            #print(contours)
            #print(binary.shape)
            #inputs=Image.fromarray(np.uint8(inputs))
            # newimg = f_map.filter(ImageFilter.CONTOUR)  
            # newimg.save(f'C:/Users/Dell/PycharmProjects/iccnn/icCNN/result/visual/clean/fmap/{idx}_{labels[0].item()}_{index}.png', 'png')
            #binary= np.expand_dims(binary, 2)
            #print(type(inputs))
            #print(inputs.shape)
            #print(f_map,inputs)
            #f_map=np.full((300,300),192)
            #f_map = cv2.resize(f_map,(300, 300,3))
            #f_map=cv2.drawContours(f_map, contours, contourIdx=-1, color=(0, 255, 0), thickness=1)
            # cv2.namedWindow('a')
            # cv2.imshow('a', inputs)
            # cv2.waitKey(0)
            #cv2.imwrite(f'C:/Users/Dell/PycharmProjects/iccnn/icCNN/result/visual/clean/fmap/{idx}_{labels[0].item()}_{index}.png', f_map)
            #f_map=cv2.imread(f'C:/Users/Dell/PycharmProjects/iccnn/icCNN/result/visual/clean/fmap/{idx}_{labels[0].item()}_{index}.png')
            #overlap = np.asarray(overlap)
            #print(idx,type(idx))
            #print(idx)
            if idx==4 and labels[0].item()==0:
                cv2.imwrite(f'C:/Users/Dell/PycharmProjects/iccnn/icCNN/result/visual/iccnn/imgs/{idx}_{labels[0].item()}.png',inputs)

            if idx ==4 and labels[0].item() ==0 and index==243:

                img=cv2.imread(f'C:/Users/Dell/PycharmProjects/iccnn/icCNN/result/visual/iccnn/imgs/{idx}_{labels[0].item()}.png')
                overlap = cv2.drawContours(img, contours,-1,(0,0,255), 5)#0,0,255 0,97,255 0,255,255
                f_map=cv2.drawContours(f_map, contours,-1,(0,0,255), 5)
                #cv2.imwrite(f'C:/Users/Dell/PycharmProjects/iccnn/icCNN/result/visual/iccnn/fmap/{idx}_{labels[0].item()}_{index}.png', f_map)
                cv2.imwrite(f'C:/Users/Dell/PycharmProjects/iccnn/icCNN/result/visual/iccnn/fmap/{idx}_{labels[0].item()}_{index}.png',f_map)
                cv2.imwrite(f'C:/Users/Dell/PycharmProjects/iccnn/icCNN/result/visual/iccnn/overlap/{idx}_{labels[0].item()}_{index}.png', overlap)
        #inputs = np.asarray(inputs)
        #cv2.imwrite(f'C:/Users/Dell/PycharmProjects/iccnn/icCNN/result/visual/clean/imgs/{idx}_{labels[0].item()}.png', inputs)


def offline_spectral_cluster(net, train_loader):
    net.eval()
    f_map = []
    for inputs, labels in tqdm(train_loader, desc='[Offline_spectral_cluster]', dynamic_ncols=True):
        inputs, labels = inputs.cuda(), labels.cuda()
        cur_fmap = net(inputs, eval=True).detach().cpu().numpy()
        f_map.append(cur_fmap)
        if len(f_map) >= 1024:
            break

    f_map = np.concatenate(f_map, axis=0)
    sample, channel, _, _ = f_map.shape
    f_map = f_map.reshape((sample, channel, -1))  # (n, c, h * w)
    mean = np.mean(f_map, axis=0)  # (c, h * w)
    f_map = f_map - mean  # (n, c, h * w)
    cov = np.mean(np.matmul(f_map, np.transpose(f_map, (0, 2, 1))), axis=0)  # np.mean((n, c, c), axis=0) -> (c, c)
    diag = np.diag(cov).reshape(channel, -1)  # (c, 1)   

    correlation = cov / (np.sqrt(np.matmul(diag, np.transpose(diag, (1, 0)))) + 1e-5) + 1
    ground_true, loss_mask_num, loss_mask_den = spectral_clustering(correlation, n_cluster=center_num)

root = 'D:/dataset/VOCdevkit/VOC2010/classification'
train_loader, test_loader = get_Data(root)
device = torch.device("cuda")
net = alex(num_class=NUM_CLASSES, pretrained=True, device=device)
#print(net)
net = net.to(device)

test(test_loader)
# offline_spectral_cluster(net, train_loader)