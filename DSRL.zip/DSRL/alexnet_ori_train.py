#!/usr/bin/env python

import torch
import torch.nn as nn
import torchvision.transforms as transforms
import torchvision.models as models
from torch.utils.data import DataLoader
from load_utils import load_state_dict_from_url
# from cub_voc import CUB_VOC
# from celeb import Celeb
import os
from tqdm import tqdm
import shutil
import numpy as np
from newPad2d import newPad2d
import torchvision.datasets as datasets
from Similar_Mask_Generate import SMGBlock
CHANNEL_NUM = 256
IS_TRAIN = 0  # 0/1
# IS_MULTI = 0
# LAYERS = '13'
# DATANAME = 'bird'
# NUM_CLASSES = 6 if IS_MULTI else 2
# if DATANAME == 'celeb':
#     NUM_CLASSES = 80
# cub_file = '/data/sw/dataset/frac_dataset'
# voc_file = '/data/sw/dataset/VOCdevkit/VOC2010/voc2010_crop'
# celeb_file = '/home/user05/fjq/dataset/CelebA/'
# log_path = '/data/fjq/iccnn/vgg/' # for model
# save_path = '/data/fjq/iccnn/basic_fmap/vgg/'  # for get_feature
# acc_path = '/data/fjq/iccnn/basic_fmap/vgg/acc/'
#
# dataset = '%s_vgg_%s_ori' % (LAYERS, DATANAME)
# log_path = log_path + dataset + '/'
# pretrain_model = log_path + 'model_2000.pth'
log_path = '/data/zsq/log/'
LAYERS = '16'
NUM_CLASSES = 2
pretrain_model = None
BATCHSIZE = 64
LR = 0.0001
EPOCH = 20

_all__ = ['alexnet']
model_urls = {
    'alexnet': 'https://download.pytorch.org/models/alexnet-owt-4df8aa71.pth',
}

class AlexNet(nn.Module):
    def __init__(self, num_classes=NUM_CLASSES, init_weights=True):
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(  
            nn.Conv2d(3, 64, 11, stride=4, padding=2),  # input[3, 224, 224]  output[48, 55, 55] 
            nn.ReLU(inplace=True),  # inplace 
            nn.MaxPool2d(kernel_size=3, stride=2),  # output[48, 27, 27] 
            nn.Conv2d(64, 192, kernel_size=5, padding=2),  # output[128, 27, 27]
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),  # output[128, 13, 13]
            nn.Conv2d(192, 384, kernel_size=3, padding=1),  # output[192, 13, 13]
            nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1),  # output[192, 13, 13]
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),  # output[128, 13, 13]
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),  # output[128, 6, 6]
        )
        self.target_layer = 15
        self.pad2d = newPad2d(1)
        self.smg = SMGBlock(channel_size=CHANNEL_NUM)
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))
        self.classifier = nn.Sequential(
            nn.Dropout(p=0.5),
        
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096, num_classes),
        )
        if init_weights:
            self._initialize_weights()

    def forward(self, x, eval=False):
        for layer in self.features[:self.target_layer + 1]:
            if isinstance(layer, nn.Conv2d):
                x = self.pad2d(x)
            x = layer(x)
        if eval:
            return x
        corre_matrix = self.smg(x)
        f_map = x.detach()
        for layer in self.features[self.target_layer + 1:]:
            if isinstance(layer, nn.Conv2d):
                # print(x.shape)
                x = self.pad2d(x)
                # print(x.shape)
            x = layer(x)
            # print(x.shape)
        x = self.avgpool(x)

        x = torch.flatten(x, 1)
        # print(x.shape)
        x = self.classifier(x)
        return x, f_map, corre_matrix

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')  
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)  
                nn.init.constant_(m.bias, 0)



def alex(num_class, device=None, pretrained=False, progress=True, **kwargs):
    if pretrained:
        kwargs['init_weights'] = False
    model = AlexNet(num_class, **kwargs)
    # print(model_urls['alexnet'])
    if pretrained:
        if pretrain_model is None:
            state_dict = load_state_dict_from_url(model_urls['alexnet'], progress=progress)
            pretrained_dict = {k: v for k, v in state_dict.items() if 'classifier' not in k}
            model_dict = model.state_dict()
            model_dict.update(pretrained_dict)
            model.load_state_dict(model_dict)
        else:
            device = torch.device("cuda")
            model = model.to(device)
            print(f'Load Pth: {pretrain_model}')
            pretrained_dict = torch.load(pretrain_model)
            # if IS_TRAIN == 0:
            #     pretrained_dict = {k[k.find('.') + 1:]: v for k, v in pretrained_dict.items()}
            model.load_state_dict(pretrained_dict)
    if device is not None:
        model = model.to(device)
    return model



def get_Data(root, batch_size, workers=1, pin_memory=1):
    traindir = os.path.join(root, 'train')
    valdir = os.path.join(root, 'val')
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])

    train_dataset = datasets.ImageFolder(
        traindir,
        transforms.Compose([
            transforms.RandomResizedCrop(300),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            normalize
        ])
    )
    val_dataset = datasets.ImageFolder(
        valdir,
        transforms.Compose([
            transforms.Resize(300),
            transforms.CenterCrop(300),
            transforms.ToTensor(),
            normalize
        ])
    )

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=workers,
        pin_memory=pin_memory,
        sampler=None
    )
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=workers,
        pin_memory=pin_memory
    )
    return train_loader, val_loader


def net_train():
    root = '/data/zsq/celeba/'
    trainset_loader, testset_loader = get_Data(root, batch_size=32, workers=1)
    # device = torch.device("cuda")
    # layer_arch = 'vgg13_bn' if LAYERS == '13' else 'vgg16_bn'
    # layer_cfg = 'B' if LAYERS == '13' else 'D'
    # model_path = os.path.join(log_path, '%s_vgg_%s_%s' % (layers, dataset_name, mytype))
    # if os.path.exists(log_path):
    #     shutil.rmtree(log_path);os.makedirs(log_path)
    # else:
    #     os.makedirs(log_path)
    if not os.path.exists(log_path):
        os.makedirs(log_path)
    device = torch.device("cuda")
    net = alex(num_class=NUM_CLASSES, pretrained=True, device=device)
    net = net.to(device)

    # Loss and Optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(net.parameters(), lr=LR)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=EPOCH, gamma=0.6)
    # test = test_celeb if DATANAME=='celeb' else test_ori
    # Train the model
    best_acc = 0.0
    save_loss = []
    for epoch in range(0, EPOCH + 1):

        net.train()
        total_loss = 0.0
        for index, (inputs, labels) in enumerate(tqdm(trainset_loader, smoothing=0.9, desc='[Train]', dynamic_ncols=True)):
            # inputs, labels = input_data
            inputs, labels = inputs.to(device), labels.long().to(device)
            optimizer.zero_grad()
            output, f_map, corre = net(inputs)
            # print(output)
            # if DATANAME != 'celeb':
            #     loss = criterion(output, labels)
            # else:
            #     loss = .0
            #     for attribution in range(NUM_CLASSES//2):
            #         loss += criterion(output[:, 2*attribution:2*attribution+2], labels[:, attribution])
            loss = criterion(output, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        scheduler.step()
        ### loss save code #####
        total_loss = float(total_loss) / len(trainset_loader)
        save_loss.append(total_loss)
        acc = test_ori(net, testset_loader)
        acc1 = test_ori(net, trainset_loader)
        print('Epoch', epoch, 'loss: %.4f' % total_loss, 'train accuracy:%.4f' % acc1, 'test accuracy:%.4f' % acc)
        # np.savez(os.path.join(log_path, 'loss.npz'), loss=np.array(save_loss))
        if acc > best_acc:
            best_acc = acc
            torch.save(net.state_dict(), log_path + f'model_{epoch}_{best_acc}.pth')
            # torch.save(net.state_dict(), log_path + f'model_{epoch}_{best_acc}.pth')
        # if epoch % 50 == 0:
        #     train_acc = test(net, trainset_loader, NUM_CLASSES)
        #     print('Epoch', epoch, 'train accuracy:%.4f' % train_acc)
        #     torch.save(net.state_dict(), log_path+'/model_%.3d.pth' % (epoch))
        # if epoch % 1 == 0:
        #     acc = test(net, testset_loader, NUM_CLASSES)
        #     print('Epoch', epoch, 'loss: %.4f' % total_loss, 'test accuracy:%.4f' % acc)
        #     if acc > best_acc and epoch >= 10:
        #         best_acc = acc
        #         torch.save(net.state_dict(), log_path+'/model_%.3d_%.4f.pth' % (epoch, best_acc))
    print('Finished Training')
    return net


# def get_feature():
#     _, testset_test = get_Data(True, DATANAME, BATCHSIZE)
#     _, testset_feature = get_Data(False, DATANAME, BATCHSIZE)
#     device = torch.device("cuda")
#     layer_arch = 'vgg13_bn' if LAYERS=='13' else 'vgg16_bn'
#     layer_cfg = 'B' if LAYERS=='13' else 'D'
#
#     if not os.path.exists(pretrain_model):
#         raise Exception("Not such pretrain-model!")
#     net = vgg(arch=layer_arch,cfg=layer_cfg,num_class=NUM_CLASSES,device=device,pretrained=False,progress=True, )
#     net = nn.DataParallel(net).to(device)
#     test = test_celeb if DATANAME=='celeb' else test_ori
#     acc = test(net, testset_test, NUM_CLASSES)
#     print('test acc:', acc)
#     #if not os.path.exists(acc_path):
#     #    os.makedirs(acc_path)
#     f = open(os.path.join(acc_path, layer_arch+'_'+DATANAME+'_test.txt'), 'w+')
#     f.write('%s\n' % layer_arch)
#     f.write('%s\n' % DATANAME)
#     f.write('acc:%f\n' % acc)
#     #if not os.path.exists(save_path):
#     #    os.makedirs(save_path)
#     testset = testset_test if DATANAME == 'voc_multi' else testset_feature
#     all_feature = []
#     for batch_step, input_data in tqdm(enumerate(testset,0),total=len(testset),smoothing=0.9):
#         inputs, labels = input_data
#         inputs, labels = inputs.cuda(), labels.cuda()
#         net.eval()
#         _, f_map = net(inputs)
#         all_feature.append(f_map.cpu().numpy())
#     all_feature = np.concatenate(all_feature, axis=0)
#     f.write('sample num:%d' % (all_feature.shape[0]))
#     f.close()
#     print(all_feature.shape)
#     np.savez_compressed(save_path+LAYERS+'_vgg_'+DATANAME+'_ori.npz', f_map=all_feature[...])
#     print('Finished?Getting Feature!')
#     return net

def test_ori(net, testdata):
    correct, total = .0, .0
    net.eval()
    for inputs, labels in tqdm(testdata, desc='[Test]', dynamic_ncols=True):
        inputs, labels = inputs.cuda(), labels.cuda()
        outputs, _,_ = net(inputs)
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum()
    return float(correct) / total


# def test_celeb(net, testdata, n_cls):
#     correct, total = .0, .0
#     ATTRIBUTION_NUM = n_cls//2
#     running_correct = np.zeros(ATTRIBUTION_NUM)
#     for inputs, labels in tqdm(testdata):
#         inputs, labels = inputs.cuda(), labels.cuda().long()
#         net.eval()
#         outputs, _ = net(inputs)
#         out = outputs.data
#         total += labels.size(0)
#         for attribution in range(ATTRIBUTION_NUM):
#             _, predicted = torch.max(out[:, 2*attribution:2*attribution+2], 1)
#             correct = (predicted == labels[:, attribution]).sum().item()
#             running_correct[attribution] += correct
#     attr_acc = running_correct / float(total)
#     return np.mean(attr_acc)

# def vgg_ori_train():
#     if IS_TRAIN:
#         net = net_train()
#     else:
#         net = get_feature()


if __name__ == '__main__':
    # vgg_ori_train()
    net_train()