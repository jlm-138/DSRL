#!/usr/bin/env python
import torch, gc
import torch.nn as nn
import math
import torchvision
import torchvision.transforms as transforms
import torchvision.models as models
from torch.utils.data import DataLoader
from load_utils import load_state_dict_from_url
from cub_voc import CUB_VOC
import os
from tqdm import tqdm
import shutil
from utils.utils import Cluster_loss, Multiclass_loss
import numpy as np
from Similar_Mask_Generate import SMGBlock
from SpectralClustering import spectral_clustering
from newPad2d import newPad2d
import torchvision.datasets as datasets
from sklearn import preprocessing
import cv2
import gc
import matplotlib.pyplot as plt
# IS_TRAIN = 0        # 0/1
# LAYERS = '18'
# DATANAME = 'voc_multi' # voc_multi
# NUM_CLASSES = 6
# cub_file = '/data/sw/dataset/frac_dataset'
# voc_file = '/data/sw/dataset/VOCdevkit/VOC2010/voc2010_crop'
# log_path = '/data/fjq/iccnn/resnet/' # for model
# save_path = '/data/fjq/iccnn/basic_fmap/resnet/'  # for get_feature
# acc_path = '/data/fjq/iccnn/basic_fmap/resnet/acc/'
#
# dataset = '%s_resnet_%s_iccnn' % (LAYERS, DATANAME)
# log_path = '/home/zsq/fmx/iccnn/log/'
# pretrain_model = log_path + 'model_2000.pth'
# BATCHSIZE = 16
# LR = 0.00001
# EPOCH = 30
# center_num = 16
# lam1 = 0.1
# lam2 = 0.1
# T = 2 # T = 2 ===> do sc each epoch
# F_MAP_SIZE = 196
# STOP_CLUSTERING = 200
# if LAYERS == '18':
#    CHANNEL_NUM = 256
# elif LAYERS == '50':
#    CHANNEL_NUM = 1024
IS_TRAIN = 0  # 0/1
# LAYERS = '18'
NUM_CLASSES = 2
save_path = '/home/jzj/icCNN/log/'  # for get_feature
log_path = '/data/zsq/log/'
pretrain_model = None
BATCHSIZE = 128  # bs
LR = 0.0001  
EPOCH = 39   
center_num = list(range(5,6))  
lam1 = 0.1
lam2 = 0.1 
T = 2  
# if LAYERS == '18':
# CHANNEL_NUM = 256
# elif LAYERS == '50':
CHANNEL_NUM = 256
feature_size = 121
_all__ = ['alexnet']
model_urls = {
    'alexnet': 'https://download.pytorch.org/models/alexnet-owt-4df8aa71.pth',
}


class AlexNet(nn.Module):
    def __init__(self, num_classes=NUM_CLASSES, init_weights=True):
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(  # 
            nn.Conv2d(3, 64, 11, stride=4, padding=2),  # 
            nn.ReLU(inplace=True),  # inplace 
            nn.MaxPool2d(kernel_size=3, stride=2),  # output[48, 27, 27] kernel_num
            nn.Conv2d(64, 192, kernel_size=5, padding=2),  # output[128, 27, 27]
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),  # output[128, 13, 13]
            nn.Conv2d(192, 384, kernel_size=3, padding=1),  # output[192, 13, 13]
            nn.ReLU(inplace=True),
            nn.Conv2d(384, 256, kernel_size=3, padding=1),  # output[192, 13, 13]
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),  # output[128, 13, 13]
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),  # output[128, 6, 6]
        )
        self.target_layer = 15
        self.pad2d = newPad2d(1)
        self.smg = SMGBlock(channel_size=CHANNEL_NUM)
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))
        self.classifier = nn.Sequential(
            nn.Dropout(p=0.5),
           
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(p=0.5),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096, num_classes),
        )
        if init_weights:
            self._initialize_weights()

    def forward(self, x, eval=False):
        for layer in self.features[:self.target_layer + 1]:
            if isinstance(layer, nn.Conv2d):
                x = self.pad2d(x)
            x = layer(x)
        if eval:
            return x
        corre_matrix = self.smg(x)
        f_map = x.detach()
        for layer in self.features[self.target_layer + 1:]:
            if isinstance(layer, nn.Conv2d):
                # print(x.shape)
                x = self.pad2d(x)
                # print(x.shape)
            x = layer(x)
            # print(x.shape)
        x = self.avgpool(x)

        x = torch.flatten(x, 1)
        # print(x.shape)
        x = self.classifier(x)
        return x, f_map, corre_matrix

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')  
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)  
                nn.init.constant_(m.bias, 0)


def alex(num_class, device=None, pretrained=False, progress=True, **kwargs):
    if pretrained:
        kwargs['init_weights'] = False
    model = AlexNet(num_class, **kwargs)
    # print(model_urls['alexnet'])
    if pretrained:
        if pretrain_model is None:
            state_dict = load_state_dict_from_url(model_urls['alexnet'], progress=progress)
            pretrained_dict = {k: v for k, v in state_dict.items() if 'classifier' not in k}
            model_dict = model.state_dict()
            model_dict.update(pretrained_dict)
            model.load_state_dict(model_dict)
        else:
            device = torch.device("cuda")
            model = model.to(device)
            print(f'Load Pth: {pretrain_model}')
            pretrained_dict = torch.load(pretrain_model)
            # if IS_TRAIN == 0:
            #     pretrained_dict = {k[k.find('.') + 1:]: v for k, v in pretrained_dict.items()}
            model.load_state_dict(pretrained_dict)
    if device is not None:
        model = model.to(device)
    return model


def get_Data(root, batch_size, workers=1, pin_memory=1):
    # val_transform = transforms.Compose([
    # transforms.Resize((224,224)),
    # transforms.ToTensor(),
    # transforms.Normalize(mean=[0.485, 0.456, 0.406],
    # std=[0.229, 0.224, 0.225])
    # ])
    # voc_helen = ['bird', 'cat', 'cow', 'dog', 'horse', 'sheep', 'helen', 'voc_multi']
    ##cub dataset###
    # label = None if is_train else 0
    # if not is_train:
    # batch_size = 1
    # if dataset_name == 'cub':
    # trainset = CUB_VOC(cub_file, dataset_name, 'iccnn', train=True, transform=val_transform, is_frac=label)
    # testset = CUB_VOC(cub_file, dataset_name, 'iccnn', train=False, transform=val_transform, is_frac=label)
    ###cropped voc dataset###
    # elif dataset_name in voc_helen:
    # trainset = CUB_VOC(voc_file, dataset_name, 'iccnn', train=True, transform=val_transform, is_frac=label)
    # testset = CUB_VOC(voc_file, dataset_name, 'iccnn', train=False, transform=val_transform, is_frac=label)
    ###celeb dataset###
    # elif dataset_name == 'celeb':
    #   trainset = Celeb(training = True, transform=None)
    #   testset = Celeb(training = False, transform=None)
    # train_loader = DataLoader(trainset, batch_size=batch_size, shuffle=True)
    # test_loader = DataLoader(testset, batch_size=batch_size, shuffle=False)
    traindir = os.path.join(root, 'train')
    valdir = os.path.join(root, 'val')
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])

    train_dataset = datasets.ImageFolder(
        traindir,
        transforms.Compose([
            transforms.RandomResizedCrop(300),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            normalize
        ])
    )
    val_dataset = datasets.ImageFolder(
        valdir,
        transforms.Compose([
            transforms.Resize(300),
            transforms.CenterCrop(300),
            transforms.ToTensor(),
            normalize
        ])
    )

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=workers,
        pin_memory=pin_memory,
        sampler=None
    )
    val_loader = torch.utils.data.DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=workers,
        pin_memory=pin_memory
    )
    return train_loader, val_loader


def net_train():
    for num in center_num:
        root = '/data/zsq/celeba/'
        trainset_loader, testset_loader = get_Data(root, batch_size=32, workers=1)
    # watch -n 0.5 nvidia-smi
    # if os.path.exists(log_path):
    # shutil.rmtree(log_path);os.makedirs(log_path)
    # else:
    # os.makedirs(log_path)
        if not os.path.exists(log_path):
            os.makedirs(log_path)
        device = torch.device("cuda")
    # if LAYERS == '18':
    # net = ResNet18(num_class=NUM_CLASSES,pretrained=True, device=device)
    # net = net.to(device)
    # elif LAYERS == '50':
    # net = ResNet50(num_class=NUM_CLASSES,pretrained=True, device=device)
    # net = net.to(device)
    # net = net.to(device)
    # Loss and Optimizer
        net = alex(num_class=NUM_CLASSES, pretrained=True, device=device)
        net = net.to(device)
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(net.parameters(), lr=LR, weight_decay=1e-2)
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=EPOCH, gamma=0.6)
        best_acc = 0.0
    # Train the model
        save_loss = []
        save_similatiry_loss = []
        save_gt = []
        save_class_loss = []
        save_total_loss = []
        va=[]
        cs_loss = Cluster_loss()
        mc_loss = Multiclass_loss(class_num=NUM_CLASSES)
        for epoch in range(EPOCH + 1):
        # if epoch % T==0 :
        # acc=0
        # with torch.no_grad():
        # loss_cluster = offline_spectral_cluster(net, trainset_loader)
        # save_gt.append(Ground_true.cpu().numpy())
        # else:
        # scheduler.step()
            if epoch % T==0 :
                acc=0
                loss2 = offline_spectral_cluster(epoch, net, trainset_loader,num)
                #va.append(vality)
            else:
                net.train()
                all_feature = []
                total_loss = 0.0
                similarity_loss = 0.0
                class_loss = 0.0
            #loss1, loss2 = offline_spectral_cluster(epoch, net, trainset_loader)
        # print(loss1,loss2)

                for index, (inputs, labels) in enumerate(tqdm(trainset_loader, smoothing=0.9, desc='[Train]', dynamic_ncols=True)):
                    inputs, labels = inputs.to(device), labels.long().to(device)
                    optimizer.zero_grad()
                #with torch.no_grad():
                    output, f_map, corre = net(inputs, eval=False)
            # print(f_map.shape)
                    clr_loss = criterion(output, labels)

            # loss2 = mc_loss.update(f_map, loss_mask_num, labels)
                    loss = clr_loss + lam2 * loss2
            # print(loss1,loss2)
            # loss = clr_loss
                    loss.backward()
                    optimizer.step()
                    total_loss += loss.item()
                    #similarity_loss += loss1.item()
                    class_loss += loss2.item()
                    clr_loss+=clr_loss.item()
                scheduler.step()
        ### loss save code #####
                clr_loss=float(clr_loss) / len(trainset_loader)
                total_loss = float(total_loss) / len(trainset_loader)
                #similarity_loss = float(similarity_loss) / len(trainset_loader)
                class_loss = float(class_loss) / len(trainset_loader)
                save_total_loss.append(total_loss)
        # save_similatiry_loss.append(similarity_loss)
        # save_class_loss.append(class_loss)
                acc = test(net, testset_loader)
                acc1 = test(net, trainset_loader)
                print('Epoch', epoch, 'loss: %.4f' % total_loss, 'train accuracy:%.4f' % acc1, 'test accuracy:%.4f' % acc,
               'space_loss:%.4f' % class_loss,'cls_loss:%.4f'%clr_loss)
        # if acc > best_acc:
                best_acc = acc
                torch.save(net.state_dict(), log_path + f'model_{epoch}_{best_acc}.pth')
        # if epoch % 5==0:
        #    acc = test(net, testset_loader)

        # print('Epoch', epoch, 'loss: %.4f' % total_loss, 'sc_loss: %.4f' % similarity_loss, 'class_loss: %.4f' % class_loss, 'test accuracy:%.4f' % acc)
        # if epoch % 100 == 0:
        # torch.save(net.state_dict(), log_path+'model_%.3d.pth' % (epoch))
        # np.savez(log_path+'loss_%.3d.npz'% (epoch), loss=np.array(save_total_loss), similarity_loss = np.array(save_similatiry_loss), class_loss = np.array(save_class_loss),gt=np.array(save_gt))
        # x_axis_data=list(range(1,EPOCH + 1,2))
        # y_axis_data=va
        # plt.plot(x_axis_data, y_axis_data, 'b*--', alpha=0.5, linewidth=1)
        # plt.xlabel('Epoch')
        # plt.ylabel('xb')
        # plt.savefig("plot %d.png"%(num), dpi=300)
        # plt.close()
        # plt.clf()
        print('Finished?Training')
    return net


def offline_spectral_cluster(epoch, net, train_data,num):
    net.eval()
    f_map = []
    for inputs, labels in tqdm(train_data, desc='[Offline_spectral_cluster]', dynamic_ncols=True):
        inputs, labels = inputs.cuda(), labels.cuda()
        cur_fmap = net(inputs, eval=True).detach().cpu().numpy()  # (32,256,11,11)

        f_map.append(cur_fmap)
        # print(f_map.shape)
    f_map = np.concatenate(f_map, axis=0)
    # print(f_map.shape)
    sample, channel, _, _ = f_map.shape
    f_map_onepart = [[] for _ in range(sample)]
    # for i in range(sample):
    # for j in range(channel):
    # a=np.unravel_index(np.argmax(f_map[i][j]), f_map[i][j].shape)
    ##print(f_map[i][j],a)
    # mask = np.zeros((11,11))
    # mask[max(a[0]-2,0):min(a[0]+2,11), max(a[1]-2,0):min(a[1]+2,11)] =1
    ##print(a,mask)
    # f_map_onepart[i].append(mask*f_map[i][j])
    ##print(f_map[i][j],f_map_onepart[i])
    for i in range(sample):
        for j in range(channel):
            x = []
            y = []

            img = cv2.resize(np.uint8(np.expand_dims(f_map[i][j], 2) * 255), (11, 11))
            # print(img)
            # gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            # print(gray)
            ret, binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
            # print(binary)
            contours, hierarchy = cv2.findContours(binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            # print(contours)
            a = [0] * len(contours)
            if len(contours) > 0:
                for k in range(0, len(contours)):
                    x.append(np.max(contours[k], axis=0))
                    y.append(np.min(contours[k], axis=0))
                    # print(k,x,y)
                    for m in range(y[k][0][0], x[k][0][0] + 1):
                        for n in range(y[k][0][1], x[k][0][1] + 1):
                            a[k] += img[n][m]
                    # print((x[k][0][0]-y[k][0][0])*(x[k][0][1]-y[k][0][1]))
                    # print()
                    p = x[k][0][0] - y[k][0][0]+1
                    q = x[k][0][1] - y[k][0][1]+1
                    a[k] = a[k] / (p + q)
                    # print()
                maxindex = a.index(max(a))
                mask = np.zeros((11, 11), dtype=np.uint8)
                polygon = contours[maxindex]  
                cv2.fillConvexPoly(mask, polygon, 1)
                f_map_onepart[i].append(mask * f_map[i][j])
            else:
                f_map_onepart[i].append(np.ones((11, 11)) * f_map[i][j])
    f_map_onepart = np.array(f_map_onepart).reshape((sample, channel, -1))
    f_map = f_map.reshape((sample, channel, -1))

    # f_map_new=[[[] for _ in range(sample)] for _ in range(channel)]
    # print(f_map)
    f_map_new = f_map.transpose(1, 0, 2)
    f_map=f_map.transpose(1, 0, 2)
    # print(f_map_new[0][0])
    # print(f_map_new[0][1])
    f_map_onepart = f_map_onepart.transpose(1, 0, 2)
    # print(f_map_onepart[0][0])
    # print(f_map_onepart[0][1])
    #loss_cluster,vality = spectral_clustering(epoch, np.array(f_map_new), num)
    loss_space = np.sum(np.square(f_map - f_map_onepart)) / sample / channel / 121
    # sv_k.append([k,num])
    # print(sv_k)
    return  loss_space


def get_feature():
    print('pretrain_model:', pretrain_model)
    _, testset_test = get_Data(True, DATANAME, BATCHSIZE)
    _, testset_feature = get_Data(False, DATANAME, BATCHSIZE)
    device = torch.device("cuda")
    net = None
    if LAYERS == '50':
        net = ResNet50(pretrained=False)
    elif LAYERS == '18':
        net = ResNet18(pretrained=False)

    acc = test(net, testset_test)
    f = open(acc_path + dataset + '_test.txt', 'w+')
    f.write('%s\n' % dataset)
    f.write('acc:%f\n' % acc)
    all_feature = []
    for batch_step, input_data in tqdm(enumerate(testset_feature, 0), total=len(testset_feature), smoothing=0.9):
        inputs, labels = input_data
        inputs, labels = inputs.to(device), labels.to(device)
        net.eval()
        f_map = net(inputs, eval=True)
        all_feature.append(f_map.detach().cpu().numpy())
    all_feature = np.concatenate(all_feature, axis=0)
    # print(all_feature.shape)
    f.write('sample num:%d' % (all_feature.shape[0]))
    f.close()
    np.savez(save_path + LAYERS + '_resnet_' + DATANAME + 'iccnn_.npz', f_map=all_feature[...])
    print('Finished?Operation!')


def test(net, testdata):
    correct, total = .0, .0
    net.eval()
    for inputs, labels in tqdm(testdata, desc='[Test]', dynamic_ncols=True):
        inputs, labels = inputs.cuda(), labels.cuda()
        outputs, _, _ = net(inputs)
        _, predicted = torch.max(outputs, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum()
    # print('test acc = ',float(correct) / total)
    return float(correct) / total


def resnet_multi_train():
    if IS_TRAIN == 1:
        net_train()
    elif IS_TRAIN == 0:
        get_feature()


net_train()