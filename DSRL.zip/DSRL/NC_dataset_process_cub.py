import torch
from collections import Counter
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
from load_utils import load_state_dict_from_url
from tqdm import tqdm
from Similar_Mask_Generate import SMGBlock
from newPad2d import newPad2d
import torchvision.datasets as datasets
from xml.etree import ElementTree as ET
import os
import cv2
import numpy as np
from numpy import *
import math
from PIL import Image
from model import alexnet
from model import vgg
part_path='D:/dataset/cub/part.txt'
image_path='D:/dataset/cub/test.txt'
file_path ='D:/dataset/cub/dataset/test'
imagesize={}
imageindex={}
partaxis=[{} for _ in range(3)]
partlist={'1':0,'6':1,'14':2}
partexist=[{} for _ in range(3)]

background= []
def getfilename(filename):
    for root, dirs, files in os.walk(filename):
        array = dirs
        if array:
            return array

def getfilesname(filename):
    for root, dirs, files in os.walk(filename):
        array = files
        if array:
            return array
category=getfilename(file_path)
image = open(image_path, 'r')

for line in image:
    line = line.strip()
    
    wordlist = line.split()
    imageindex[wordlist[1]]=wordlist[0]
part = open(part_path, 'r')
for line2 in part:
    line2 = line2.strip()
    wordlist2 = line2.split()
    partaxis[int(wordlist2[1])][wordlist2[0]]=(wordlist2[2], wordlist2[3])
    partexist[int(wordlist2[1])][wordlist2[0]]=int(wordlist2[4])
for clas in category:
    file=file_path+'/'+clas
    #print(file)
    picture=getfilesname(file)
    #print(picture)
    for pic in picture:
        pho=file+'/'+pic
        img=cv2.imread(pho)
        sp = img.shape[0:2]
        imagesize[imageindex[pic]]=sp

CHANNEL_NUM = 512
NUM_CLASSES = 2
maxvalues=[[[] for _ in range(3)]for _ in range(CHANNEL_NUM)]
maxindex=[[[] for _ in range(3)]for _ in range(CHANNEL_NUM)]
maxpart=[[[] for _ in range(3)]for _ in range(CHANNEL_NUM)]
#maxmarginpart=[[[] for _ in range(3)]for _ in range(CHANNEL_NUM)]
formalsize=[]
def test(root,lines):
    net.eval()
    for i in range(5794):
        tpath = os.path.join(root + lines[i])
        print(tpath)
        fopen = Image.open(tpath)
        img = cv2.imread(tpath)
        size = list(img.shape[0:2])
        size[0], size[1] = size[1], size[0]
        normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                         std=[0.229, 0.224, 0.225])
        transform = transforms.Compose([
            transforms.Resize(300),
            transforms.CenterCrop(300),
            transforms.ToTensor(),
            normalize
        ])
        inputs = transform(fopen).cuda()
        inputs = inputs.unsqueeze(0)
        outputs, f_maps= net(inputs)
        #print(f_maps.size())
        f_maps = f_maps.squeeze().cpu().detach().numpy()
        formalsize.append(math.sqrt(size[0]**2+size[1]**2))
        for index, f_map in enumerate(f_maps):
            if index not in background:
                x = []
                y = []
                img = cv2.resize(np.uint8(np.expand_dims(f_map, 2) * 255), tuple(size))
                ret, binary = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
                contours, hierarchy = cv2.findContours(binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
                a = [0] * len(contours)
                if len(contours) > 0:
                    for k in range(0, len(contours)):
                        x.append(np.max(contours[k], axis=0))
                        y.append(np.min(contours[k], axis=0))
                    # print(k,x,y)
                        for m in range(y[k][0][0], x[k][0][0] + 1):
                            for n in range(y[k][0][1], x[k][0][1] + 1):
                                a[k] += img[n][m]
                    # print((x[k][0][0]-y[k][0][0])*(x[k][0][1]-y[k][0][1]))
                    # print()
                        p = x[k][0][0] - y[k][0][0]+1
                        q = x[k][0][1] - y[k][0][1]+1

                        a[k] = a[k] / (p + q)
                    # print()

                    for j in range(3):
                        temp=a*partexist[j][imageindex[lines[i]]]

                        if (np.array(temp)==0).all():
                            maxvalues[index][j].append(0)
                            maxpart[index][j].append(None)
                        else:
                            maxvalues[index][j].append(max(a) * partexist[j][imageindex[lines[i]]])
                            maxvolindex=temp.index(max(temp))
                            maxpart[index][j].append(((x[maxvolindex][0][0] +y[maxvolindex][0][0])/2,x[maxvolindex][0][1] + y[maxvolindex][0][1]/2))

                else:
                    for part in range(3):
                        maxvalues[index][part].append(0)
                        maxpart[index][part].append(None)
    for i in range(len(maxvalues)):
        for j in range(3):
            b = np.array(maxvalues[i][j]).argsort()[-100:][::-1]
            maxindex[i][j].append(b)

    return maxvalues,maxindex,maxpart
root = 'D:/dataset/cub/classification/val/bird/'
#train_loader, test_loader = get_Data(root)
device = torch.device("cuda")
net = vgg.vgg16(arch='vgg16', cfg='D', num_class=NUM_CLASSES, device=device, pretrained=True, progress=True)
net = net.to(device)
f=open(r'D:\dataset\cub\classification\val.txt','r')
lines=f.read().splitlines()
maxvalues,maxindex,maxpart=test(root,lines)

result=[[] for _ in range(CHANNEL_NUM)]
mean1=[]
for i in range(CHANNEL_NUM):
    if i not in background:
        for j in range(3):
            d = []
            for k in range(5794):
                if (maxpart[i][j][k]!=None) and (k in maxindex[i][j][0]):
                #print(i,j,k,maxpart[i][j][k][0],partaxis[j][imageindex[lines[k]]][0],maxpart[i][j][k][1],partaxis[j][imageindex[lines[k]]][1])
                    d.append((math.sqrt((float(maxpart[i][j][k][0])-float(partaxis[j][imageindex[lines[k]]][0]))**2+(float(maxpart[i][j][k][1])-float(partaxis[j][imageindex[lines[k]]][1]))**2))/formalsize[k])
            if d!=[]:
                D=np.std(d)
            #print(D)
                result[i].append(D)
            #print(result)
for i in range(len(result)):
    if result[i]!=[]:
        mean1.append(np.mean(result[i]))
mean=np.mean(mean1)
print(mean)



